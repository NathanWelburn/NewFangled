$(document).ready(function(){

  var open = false;
  
	$('#nav-icon').click(function(){
	    $(this).toggleClass('open');

        if(open == false){
            $(".nav-overlay").css({ "display": "block" });
            open = true;
        }
        else if(open == true){
            $(".nav-overlay").css({ "display": "none" });
            open = false;
        }

	});
});
